package xyz.ctih1;

import java.net.MalformedURLException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		run();
	}
	public static void run() {
		try {
			RandomWord.GenerateWord();
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

	
}
