package xyz.ctih1;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

public class RandomWord {
	
	public static void GenerateWord() throws IOException {
		URL url = new URL("https://random-word-api.herokuapp.com/word?length=5");
		HttpURLConnection con = (HttpURLConnection) url.openConnection();
		
		System.out.println(url);
		
	}
	
}
