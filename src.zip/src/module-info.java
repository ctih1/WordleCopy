/**
 * 
 */
/**
 * 
 */
module WordleKopio {
}